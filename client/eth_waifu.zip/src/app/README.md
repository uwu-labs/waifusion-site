The organization of this `src/app` folder is as follows:

- `src/app` the files in this folder represent dynamic routes for the react app.
- `src/app/components` contains common components for the dynamic react app.
- `src/app/utils` contains common utility vars/functions used throughout the app
- `src/app/wallets` contains the integrations for various wallets
- `src/app/stores` contains the React Data-Stores for maintaining state

