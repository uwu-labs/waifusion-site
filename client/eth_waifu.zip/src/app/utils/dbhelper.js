
import { GLOBALS } from './globals.js';
const IPFS = require('ipfs-core')
let node = null;

// const node = await IPFS.create()

    const getIpfsNode = async () => {
        if(node == null)
        {
            node = await IPFS.create();
        }
        return node;
    }

    var getImageIdFromIndex = (index) => {
        return ((new Number(index) + GLOBALS.STARTING_INDEX) % 16384).toString();
    };

    const cleanWaifus = (waifus) => {
        //map each mask in masks to a object that has
        //all the info in a json format to make filtering easy
        return waifus.map((waifu)=>{
            
            return{
                index: waifu['index'],
                sha256: waifu.sha256,
                HeadAccessory: waifu.HeadAccessory,
                headaccessoryStyle: waifu.headaccessoryStyle,
                Top: waifu.Top,
                TopColor: waifu.TopColor,
                Bottom: waifu.Bottom, 
                BottomColor: waifu.BottomColor, 
                Wings: waifu.Wings, 
                WingsColor: waifu.WingsColor, 
                Tail: waifu.Tail, 
                TailColor: waifu.TailColor, 
                HandAccessory: waifu.HandAccessory, 
                Skintone: waifu.Skintone, 
                BodySize: waifu.BodySize, 
                Background: waifu.Background, 
                BackgroundStyle: waifu.BackgroundStyle, 
                Face: waifu.Face, 
                Hairstyle: waifu.Hairstyle, 
                HairColor: waifu.HairColor, 
                Eyes: waifu.Eyes, 
                SpeechBubble: waifu.SpeechBubble, 
                Socks: waifu.Socks, 
                SocksColor: waifu.SocksColor, 
                NeckAccessory: waifu.NeckAccessory, 
                NeckAccessoryColor: waifu.NeckAccessoryColor, 
                previewUrl: GLOBALS.WAIFUS_VIEWABLE_URL.concat("/",getImageIdFromIndex(waifu['index']), ".png")
        };
        });
    }

    const extractTraits = (masks, trait) => {
        //Return an array of masks that have the trait
    }

    const loadWaifus = async () => {
        //This is the one that grabs all the info from ipfs
        //names.json
        //Parses the json 
        //GLOBALS.WAIFUS_URL
        var cleanedWaifus =[];
        try {
                
            let client = await getIpfsNode();

            const stream = client.cat(GLOBALS.WAIFUS_JSON_HASH)
            let data = ''

            for await (const chunk of stream) {
            // chunks of data are returned as a Buffer, convert it back to a string
                data += chunk.toString()
            }
            var waifuArray = JSON.parse(data);

            cleanedWaifus = cleanWaifus(waifuArray);
            
        } catch (error) {
                
        }

        return cleanedWaifus;

    }

    const getWaifus = ({offest, limit, filter, search}) => {
        //This grabs the masks that meet criteria i.e. pagination
    }

    const getWaifuById = async (id) => {
        //return mask in masks from server? from loadHashMasks?
        var waifusArr = loadWaifus();
        var result = waifusArr.find(item => {
            return item.index == id;
        })
        return result
    }


export {
    loadWaifus,
    getWaifus,
    getWaifuById
}
