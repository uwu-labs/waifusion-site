import App from '../app/app';
export default App;
